package com.cn.cnpayment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CnPaymentApplicationTests {

	@Test
	void contextLoads() {
	}

}
